# include "pointmath.h"

Point getScale2xPoint(const Point*pp)
{
    Point p2;
    p2.xpos=(pp->xpos)*2;
    p2.ypos=(pp->ypos)*2;
    return p2;
}