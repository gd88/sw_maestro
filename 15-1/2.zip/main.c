# include "pointmath.h"
# include <stdio.h>
# include "point.h"

int main()
{
    Point p1;
    scanf("%d %d",&(p1.xpos), &(p1.ypos));
    Point p3=getScale2xPoint(&p1);
    printf("%d %d", p3.xpos, p3.ypos);


    return 0;
}