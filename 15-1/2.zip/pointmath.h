#pragma once

# include "point.h"
Point getScale2xPoint(const Point*pp);