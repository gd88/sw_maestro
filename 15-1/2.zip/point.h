#pragma once

typedef struct 
{
    int xpos;
    int ypos;
} Point;
